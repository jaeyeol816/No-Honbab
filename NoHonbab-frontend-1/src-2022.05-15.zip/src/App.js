import NewExpense from "./component/NewExpense/NewExpense";
import Exist from'./component/ExistMember/Exist'

function App() {
  return (
    <div>
      
      <NewExpense></NewExpense>
      <Exist></Exist>
     
    </div>
  );
}

export default App;

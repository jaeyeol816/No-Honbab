import { useState } from "react";
import axios from 'axios';

import "./ExpenseForm.css";

function ExpenseForm() {
  const [enteredNickname,setEnteredNickname]=useState(''); //nickname handler
  const [enteredAge, setEnteredAge] = useState(0); // age handler
  const [enteredMbti, setEnteredMbti] = useState("ISTJ"); // mbti handler
  const [enteredPlace, setEnterdPlace] = useState(0); // place handler
  const [enteredFoodtype, setEnteredFoodtype] = useState(0); // foodtype handler
  const [enteredGender, setEnteredGender] = useState(0); // gender handler
  const [enteredKakaoId, setEnteredKakaoId] = useState(''); // kakaoid handler 
  const [enteredHour,setEnteredHour]=useState(0); // hour handler
  const [enteredMinute,setEnteredMinute]=useState(0); // minute handler
  // const [userInput, setUserInput] = useState({
  // enteredTitle: "",
  // enteredAmount: "",
  // enteredDate: "",
  //});
  function nicknameChangeHandler(event) {
    setEnteredNickname(event.target.value);
    // setUserInput({
    //    ...userInput,
    //    enteredTitle:event.target.value
    //  })
    // setUserInput((prevState)=>{
    //   return {...prevState,enteredTitle: event.target.value}
    // })
  }
  function ageChangeHandler(event) {
    setEnteredAge(event.target.value);
    // setUserInput({
    //  ...userInput,
    // enteredAmount: event.target.value,
    // });
  }

  function mbtiChangeHandler(event) {
    // mbti handler
    setEnteredMbti(event.target.value);
  }
  function placeChangeHandler(event) {
    setEnterdPlace(event.target.value);
  }
  function foodtypeChangeHandler(event) {
    setEnteredFoodtype(event.target.value);
  }
  function genderChangeHandler(event) {
    setEnteredGender(event.target.value);
  }
  function kakaoidChangeHandler(event) {
    setEnteredKakaoId(event.target.value);
  }
  function hourChangeHandler(event){
    setEnteredHour(event.target.value);
  }
  function minuteChangeHandler(event){
    setEnteredMinute(event.target.value);
  }

  const submitHandler = (event) => {
    event.preventDefault();

    const expenseData = {
      nickname: enteredNickname,
      hour: Number(enteredHour),
      minute: Number(enteredMinute),
      place: Number(enteredPlace),
      food_type: Number(enteredFoodtype),
      gender: Number(enteredGender),
      age: Number(enteredAge),
      mbti: enteredMbti,
      kakao_id: enteredKakaoId
      
    };
    console.log(expenseData);

    axios({
      method:"POST",
      url: 'https://jsonplaceholder.typicode.com/posts',
      JSON:{

        nickname: enteredNickname,
        hour: Number(enteredHour),
        minute: Number(enteredMinute),
        place: Number(enteredPlace),
        food_type: Number(enteredFoodtype),
        gender: Number(enteredGender),
        age: Number(enteredAge),
        mbti: enteredMbti,
        kakao_id: enteredKakaoId

      }
  }).then((res)=>{
      if(res.status===200)
      {
        alert('정상 처리');
      }
      else if(res.status===405)
      {
        alert('이미 등록된 닉네임입니다.');
      }
      else if(res.status===408)
      {
        alert('기타 오류 발생');
      }
      else
      {
        alert('그 외');
        console.log(res.status);
      }
      
  }).catch(error=>{
      alert('등록 실패');
      console.log(error);
      throw new Error(error);
  });

    setEnteredNickname("");
    setEnteredAge(0);
    setEnteredMbti(0);
    setEnterdPlace(0);
    setEnteredFoodtype(0);
    setEnteredGender(0);
    setEnteredKakaoId("");
    setEnteredHour(0);
    setEnteredMinute(0);
  };

  return (
    <form onSubmit={submitHandler}>
      <div className="new-expense__controls">
        <h2 className="temp-block">신규 회원</h2>
        <div className="new-expense__control">
          <label>NickName</label>
          <input
            type="text"
            value={enteredNickname}
            onChange={nicknameChangeHandler}
            maxLength="10"
            minLength="2"
          ></input>
        </div>
        <div className="new-expense__control">
          <label>Age</label>
          <input
            type="number"
            min="0"
            step="1"
            value={enteredAge}
            onChange={ageChangeHandler}
          ></input>
        </div>
        <div className="new-expense__control">
          <label>MBTI</label>
          <select value={enteredMbti} onChange={mbtiChangeHandler}>
            <option value="ISTJ">ISTJ</option>
            <option value="ISTP">ISTP</option>
            <option value="ISFJ">ISFJ</option>
            <option value="ISFP">ISFP</option>
            <option value="INTJ">INTJ</option>
            <option value="INTP">INTP</option>
            <option value="INFJ">INFJ</option>
            <option value="INFP">INFP</option>
            <option value="ESTJ">ESTJ</option>
            <option value="ESTP">ESTP</option>
            <option value="ESFJ">ESFJ</option>
            <option value="ESFP">ESFP</option>
            <option value="ENTJ">ENTJ</option>
            <option value="ENTP">ENTP</option>
            <option value="ENFJ">ENFJ</option>
            <option value="ENFP">ENFP</option>
          </select>
        </div>
        <div className="new-expense__control">
          <label>Place</label>
          <select value={enteredPlace} onChange={placeChangeHandler}>
            <option value="0">경영관</option>
            <option value="1">600주년 기념관</option>
            <option value="2">정문</option>
            <option value="3">쪽문</option>
            <option value="4">대학로</option>
          </select>
        </div>
        <div className="new-expense__control">
          <label>Food-Type</label>
          <select value={enteredFoodtype} onChange={foodtypeChangeHandler}>
            <option value="0">아무거나</option>
            <option value="1">한식</option>
            <option value="2">일식</option>
            <option value="3">중신</option>
            <option value="4">이탈리안</option>
            <option value="5">양식</option>
            <option value="6">아시안푸드</option>
            <option value="7">패스트푸드</option>
          </select>
        </div>
        <div className="new-expense__control">
          <label>Gender</label>
          <select value={enteredGender} onChange={genderChangeHandler}>
            <option value="0">남성</option>
            <option value="1">여성</option>
          </select>
        </div>
        <div className="new-expense__control">
          <label>Kakao ID</label>
          <input
            type="text"
            value={enteredKakaoId}
            onChange={kakaoidChangeHandler}
            maxLength="20"
            minLength="1"
          ></input>
        </div>
        <div className="new-expense__control">
          <label>hour</label>
          <input
            type="number"
            min="0"
            step="1"
            max='24'
            value={enteredHour}
            onChange={hourChangeHandler}
          ></input>
        </div>
        <div className="new-expense__control">
          <label>minute</label>
          <input
            type="number"
            min="0"
            step="15"
            max='60'
            value={enteredMinute}
            onChange={minuteChangeHandler}
          ></input>
        </div>
       {/*<div className="new-expense__control">           -- timeticker라는 거 이용하면 가능 - https://shy1008.tistory.com/35 보기
          <label>Time</label>
          <input
            type="time"
            value={enteredTime}
            step='900'
            min='12:00'
            max='20:00'
            onChange={timeChangeHandler}
          ></input>
        </div>*/}
      </div>
      <div className="new-expense__actions">
        <button type="submit">Add Expense</button>
      </div>
    </form>
  );
}

export default ExpenseForm;

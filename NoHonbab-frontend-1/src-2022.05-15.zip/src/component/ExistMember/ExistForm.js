import { useState } from "react";
import axios from "axios";
import MatchedMember from "./MatchedMember";

import "./ExistForm.css";

function ExistForm() {
  let matchingMember;
  const [enteredNickname, setEnteredNickname] = useState(""); //nickname handler

  function nicknameChangeHandler(event) {
    setEnteredNickname(event.target.value);
  }
  
  const submitHandler = (event) => {
    alert("매칭 확인 전송");
    event.preventDefault();

    axios({
      method: "GET",
      url: "https://jsonplaceholder.typicode.com/posts",
      JSON: {
        nickname: enteredNickname,
      },
    })
      .then((res) => {
        alert("hello");
        console.log(res.status);            // 서버 상태 console.log
        if (res.status === 201) {
          alert("아직 매칭중입니다.");
        } else if (res.status === 470) {
          alert("매칭 등록되지 않은 사용자입니다.");
        } else if (res.status === 408) {
          alert("서버 오류입니다. 다시 매칭 확인해주세요");
        } else if (res.status === 202) {
          // 매칭된 사람 있음
          matchingMember = res.data;
          console.log(res.data.partner);             // 서버에서 get한 데이터
          alert("사용자 정보를 출력하겠습니다.");
          MatchedMember(matchingMember);                 // 임시서버에서 돌리는 거라 데이터 이름 문제가 있음
          console.log("props 전달 완료");
        }
      })
      .catch((error) => {
        alert("실패");
        console.log(error);
        throw new Error(error);
      });

    setEnteredNickname("");
  };

  const deleteMember = () => {
    alert("삭제 전송");
    axios({
      method: "POST",
      url: "https://jsonplaceholder.typicode.com/posts",
      JSON: {
        nickname: enteredNickname,
      },
    })
      .then((res) => {
        alert("통신 성공");
        console.log(res.status); // 응답 status 출력
        if (res.status === 480) {
          // 응답이 480일 때 알림창 띄움
          alert("존재하지 않는 닉네임입니다.");
        } else if(res.status===203)
        { // 응답이 제대로 처리 되었을 때
          alert("사용자 정보를 삭제 했습니다.");
        }
        else if(res.status===408)
        {
          alert('기타 오류');
        }
      })
      .catch((error) => {
        alert("통신 실패");
        console.log(error);
        throw new Error(error);
      });

    setEnteredNickname("");
  };

  return (
    <div>
      <form onSubmit={submitHandler}>
        <div className="new-expense__controls">
          <h2 className="temp-block">기존 회원</h2>
          <div className="new-expense__control">
            <label>NickName</label>
            <input
              type="text"
              value={enteredNickname}
              onChange={nicknameChangeHandler}
              maxLength="10"
              minLength="2"
            ></input>
          </div>
        </div>
        <div className="new-expense__actions">
          <button type="button" onClick={deleteMember}>
            매칭 취소
          </button>
        </div>
        <div className="new-expense__actions">
          <button type="submit">매칭 확인</button>
        </div>
      </form>
    </div>
  );
}

export default ExistForm;

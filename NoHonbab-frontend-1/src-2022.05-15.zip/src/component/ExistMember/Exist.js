import ExistForm from "./ExistForm";
import "./Exist.css";

function Exist() {
  return(
  <div>
    <div className="new-expense">
      <ExistForm></ExistForm>
    </div>

  </div>
  );
}

export default Exist;

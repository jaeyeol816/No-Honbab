import './Exist.css'

function MatchedMember(props){
   let memberData={
       id:props.parter.id,
       nickname:props.parter.nickname,
       month:props.parter.month,
       date:props.parter.date,
       minute:props.parter.minute,
       place:props.parter.place,
       food_type:props.parter.food_type,
       gender:props.parter.gender,
       age:props.parter.age,
       mbti_1:props.parter.mbti_1,
       mbti_2:props.parter.mbti_2,
       mbti_3:props.parter.mbti_3,
       mbti_4:props.parter.mbti_4,
       kakao_id:props.parter.kakao_id
   }
   console.log('----------memeberData ---------')
   console.log(memberData);
   
}

export default MatchedMember;